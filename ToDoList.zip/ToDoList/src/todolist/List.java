package todolist;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class List extends JPanel {

    private List<Task> tasks;
    private static final String FILE_NAME = "tasks.ser";

    public List() {
        initializeLayout();
        loadTasks();
    }

    private void initializeLayout() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(400, 560));
    }

    private void loadTasks() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            tasks = (List<Task>) ois.readObject();
            for (Task task : tasks) {
                add(task);
            }
        } catch (FileNotFoundException e) {
            tasks = new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void saveTasks() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(tasks);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateNumbers() {
        revalidate();
        repaint();
    }

    public void removeCompletedTasks() {
        for (Component c : getComponents()) {
            if (c instanceof Task && ((Task) c).getState()) {
                remove(c);
            }
        }
        updateNumbers();
    }
}
