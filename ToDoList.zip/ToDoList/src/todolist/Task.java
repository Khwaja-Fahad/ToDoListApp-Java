package todolist;

import javax.swing.*;
import java.awt.*;

public class Task extends JPanel {

    private JTextField taskDetailsField;
    private JTextField dateField;
    private JButton doneButton;
    private JButton undoneButton;
    private boolean checked;

    public Task() {
        initializeComponents();
        setupLayout();
        setupActions();
    }

    private void initializeComponents() {
        setPreferredSize(new Dimension(400, 60));
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        taskDetailsField = new JTextField("Task Details Here");
        dateField = new JTextField("Date Here");
        doneButton = new JButton("Done");
        undoneButton = new JButton("Undone");
        checked = false;
    }

    private void setupLayout() {
        add(taskDetailsField, BorderLayout.CENTER);
        add(dateField, BorderLayout.EAST);
        add(doneButton, BorderLayout.WEST);
        add(undoneButton, BorderLayout.SOUTH);
    }

    private void setupActions() {
        doneButton.addActionListener(e -> markAsDone());
        undoneButton.addActionListener(e -> markAsUndone());
    }

    private void markAsDone() {
        setBackground(Color.GREEN);
        taskDetailsField.setBackground(Color.GREEN);
        dateField.setBackground(Color.GREEN);
        checked = true;
    }

    private void markAsUndone() {
        setBackground(Color.RED);
        taskDetailsField.setBackground(Color.RED);
        dateField.setBackground(Color.RED);
        checked = false;
    }

    public boolean getState() {
        return checked;
    }

    public void setTaskDetails(String taskDetails) {
        taskDetailsField.setText(taskDetails);
    }

    public void setDate(String date) {
        dateField.setText(date);
    }
}
