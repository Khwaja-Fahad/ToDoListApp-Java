package todolist;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Footer extends JPanel {

    private JButton newTask;
    private JButton clear;
    private JButton logout;
    private List list;

    public Footer(List list) {
        this.list = list;

        this.setPreferredSize(new Dimension(400, 40));

        newTask = new JButton("Add New Task");
        clear = new JButton("Clear Done Tasks");
        logout = new JButton("Logout");

        add(newTask);
        add(Box.createHorizontalStrut(20));
        add(clear);
        add(Box.createHorizontalStrut(20));
        add(logout);

        newTask.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewTask();
            }
        });

        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearDoneTasks();
            }
        });

        logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Close the program
            }
        });
    }

    private void addNewTask() {
        TaskInputDialog taskInputDialog = new TaskInputDialog(list);
        taskInputDialog.setVisible(true);
    }

    private void clearDoneTasks() {
        list.removeCompletedTasks();
    }
}
