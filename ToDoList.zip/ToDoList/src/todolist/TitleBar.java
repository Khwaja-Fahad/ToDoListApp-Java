package todolist;

import javax.swing.*;
import java.awt.*;

public class TitleBar extends JPanel {

    public TitleBar() {
        initializeComponents();
    }

    private void initializeComponents() {
        setPreferredSize(new Dimension(400, 80));

        JLabel titleText = new JLabel("To Do List");
        titleText.setFont(new Font("Sans-serif", Font.BOLD, 20));
        titleText.setHorizontalAlignment(SwingConstants.CENTER);
        titleText.setForeground(Color.BLUE);
        add(titleText);
    }
}
