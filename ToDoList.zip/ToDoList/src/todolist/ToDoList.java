package todolist;

import javax.swing.*;

public class ToDoList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Login log = new Login();
            log.setTitle("Login Page");
            log.setVisible(true);
        });
    }
}
