package todolist;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TaskInputDialog extends JFrame {
    private JTextField taskDetailsField;
    private JComboBox<String> dayComboBox;
    private JComboBox<String> monthComboBox;
    private JComboBox<String> yearComboBox;
    private JButton selectDateButton;
    private JButton saveButton;
    private List list;

    public TaskInputDialog(List list) {
        this.list = list;
        initializeComponents();
        setupLayout();
        setupActions();
    }

    private void initializeComponents() {
        setTitle("Add New Task");
        setSize(500, 300); // Adjusted size to match the login window
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        taskDetailsField = new JTextField(20); // Reduced width to match login page
        dayComboBox = new JComboBox<>(getDays());
        monthComboBox = new JComboBox<>(getMonths());
        yearComboBox = new JComboBox<>(getYears());
        selectDateButton = new JButton("Select Date");
        saveButton = new JButton("Save Task");

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Task Details: "), gbc);
        gbc.gridwidth = 4; // Span multiple columns
        gbc.gridx = 1;
        inputPanel.add(taskDetailsField, gbc);

        gbc.gridwidth = 1; // Reset grid width
        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Date: "), gbc);
        gbc.gridx = 1;
        inputPanel.add(dayComboBox, gbc);

        gbc.gridx = 2;
        inputPanel.add(new JLabel("Month: "), gbc);
        gbc.gridx = 3;
        inputPanel.add(monthComboBox, gbc);

        gbc.gridx = 4;
        inputPanel.add(new JLabel("Year: "), gbc);
        gbc.gridx = 5;
        inputPanel.add(yearComboBox, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 5;
        inputPanel.add(saveButton, gbc);

        add(inputPanel);
    }

    private void setupLayout() {
        // Additional setup if needed
    }

    private void setupActions() {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveTask();
            }
        });
    }

    private String[] getDays() {
        String[] days = new String[31];
        for (int i = 0; i < 31; i++) {
            days[i] = String.valueOf(i + 1);
        }
        return days;
    }

    private String[] getMonths() {
        String[] months = new String[12];
        for (int i = 0; i < 12; i++) {
            months[i] = String.valueOf(i + 1);
        }
        return months;
    }

    private String[] getYears() {
        String[] years = new String[10];
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = 0; i < 10; i++) {
            years[i] = String.valueOf(currentYear + i);
        }
        return years;
    }

    private void saveTask() {
        String taskDetails = taskDetailsField.getText();
        String selectedDate = dayComboBox.getSelectedItem() + "/" + monthComboBox.getSelectedItem() + "/" + yearComboBox.getSelectedItem();

        if (taskDetails.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Task details cannot be empty.");
            return;
        }

        Task task = new Task();
        task.setTaskDetails(taskDetails);
        task.setDate(selectedDate);
        list.add(task);
        list.updateNumbers();
        list.revalidate();
        dispose();
    }
}
