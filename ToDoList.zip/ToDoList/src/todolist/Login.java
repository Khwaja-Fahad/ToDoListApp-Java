package todolist;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class Login extends JFrame {
    private static Map<String, String> userCredentials = new HashMap<>();
    private static String currentUser;

    public Login() {
        initializeComponents();
    }

    private void initializeComponents() {
        setTitle("Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel loginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JTextField emailField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel emailLabel = new JLabel("Email: ");
        loginPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        loginPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passwordLabel = new JLabel("Password: ");
        loginPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        loginPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        loginButton.setForeground(Color.BLUE);
        loginPanel.add(loginButton, gbc);

        gbc.gridy = 3;
        loginPanel.add(registerButton, gbc);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                if (authenticateUser(email, password)) {
                    currentUser = email;
                    showHomePage(); // Call method to show home page
                    dispose(); // Close login frame
                } else {
                    JOptionPane.showMessageDialog(Login.this, "Invalid email or password. Try again.");
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showRegistrationDialog(); // Call method to show registration dialog
            }
        });

        add(loginPanel);
        setVisible(true);
    }

    private boolean authenticateUser(String email, String password) {
        return userCredentials.containsKey(email) && userCredentials.get(email).equals(password);
    }

    private void showHomePage() {
        // Open the AppFrame
        AppFrame appFrame = new AppFrame();
        appFrame.setVisible(true);
    }

    private void showRegistrationDialog() {
        JFrame registrationFrame = new JFrame("Register");
        registrationFrame.setSize(400, 300);
        registrationFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel registerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JTextField emailField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JButton registerButton = new JButton("Register");

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel emailLabel = new JLabel("Email: ");
        registerPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        registerPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passwordLabel = new JLabel("Password: ");
        registerPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        registerPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        registerPanel.add(registerButton, gbc);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());

                if (userCredentials.containsKey(email)) {
                    JOptionPane.showMessageDialog(registrationFrame, "Email already registered. Please use a different email.");
                } else {
                    userCredentials.put(email, password);
                    JOptionPane.showMessageDialog(registrationFrame, "Registration successful. You can now login.");
                    registrationFrame.dispose();
                }
            }
        });

        registrationFrame.add(registerPanel);
        registrationFrame.setVisible(true);
    }

    public static void setUserCredentials(Map<String, String> credentials) {
        userCredentials = credentials;
    }

    public static String getCurrentUser() {
        return currentUser;
    }
}
