package todolist;

import javax.swing.*;
import java.awt.*;

public class AppFrame extends JFrame {

    private TitleBar title;
    private Footer footer;
    private List list;

    public AppFrame() {
        initializeComponents();
        setupFrame();
    }

    private void initializeComponents() {
        title = new TitleBar();
        list = new List();
        footer = new Footer(list); // Pass the list instance to the Footer
    }

    private void setupFrame() {
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.setLocationRelativeTo(null); // Center the frame on the screen

        this.add(title, BorderLayout.NORTH);
        this.add(footer, BorderLayout.SOUTH);
        this.add(new JScrollPane(list), BorderLayout.CENTER); // Add list inside a scroll pane

        pack(); // Adjust frame size to fit components
    }
}
